from pydantic import BaseModel, Field
from datetime import datetime
from typing import List, Optional
from enum import Enum

class LeaveType(str, Enum):
    annual = "annual"
    sick = "sick"

class LeaveBase(BaseModel):
    leave_type: LeaveType
    start_date: datetime
    end_date: datetime
    days: float

class LeaveCreate(LeaveBase):
    pass

class LeaveResponse(LeaveBase):
    leave_id: int
    user_id: str
    created_at: datetime

    class Config:
        orm_mode = True

class UserBase(BaseModel):
    name: Optional[str] = None

class UserCreate(UserBase):
    pass

class UserResponse(UserBase):
    id: str
    annual_leave_balance: float
    sick_leave_balance: float

    class Config:
        orm_mode = True

class LeaveBalanceResponse(BaseModel):
    user_id: str
    annual_leave_balance: float
    sick_leave_balance: float 