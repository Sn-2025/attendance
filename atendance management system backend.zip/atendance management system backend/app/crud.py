from sqlalchemy.orm import Session
from . import models, schemas
from datetime import datetime
from fastapi import HTTPException
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_user(db: Session, user_id: str):
    return db.query(models.User).filter(models.User.id == user_id).first()

def create_user(db: Session, user_id: str, name: str = None):
    db_user = models.User(id=user_id, name=name)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_or_create_user(db: Session, user_id: str):
    user = get_user(db, user_id)
    if not user:
        user = create_user(db, user_id)
    else:
        # 确保获取最新数据
        db.refresh(user)
    return user

def get_leave_balance(db: Session, user_id: str):
    # 强制从数据库刷新用户数据
    user = get_or_create_user(db, user_id)
    
    # 确保获取最新数据
    db.refresh(user)
    
    return user

def create_leave_record(db: Session, leave: schemas.LeaveCreate, user_id: str):
    user = get_or_create_user(db, user_id)
    
    logger.info(f"用户 {user_id} 当前假期余额: 年假={user.annual_leave_balance}, 病假={user.sick_leave_balance}")
    logger.info(f"请假类型: {leave.leave_type}, 类型: {type(leave.leave_type)}")
    
    # 检查假期余额是否足够 - 使用字符串值比较
    leave_type_str = str(leave.leave_type.value if hasattr(leave.leave_type, 'value') else leave.leave_type)
    
    if leave_type_str == "annual" and user.annual_leave_balance < leave.days:
        raise HTTPException(status_code=400, detail="年假余额不足")
    elif leave_type_str == "sick" and user.sick_leave_balance < leave.days:
        raise HTTPException(status_code=400, detail="病假余额不足")
    
    # 创建请假记录
    db_leave = models.LeaveRecord(
        user_id=user_id,
        leave_type=leave_type_str,  # 使用字符串值
        start_date=leave.start_date,
        end_date=leave.end_date,
        days=leave.days
    )
    db.add(db_leave)
    
    # 更新用户假期余额
    if leave_type_str == "annual":
        old_balance = user.annual_leave_balance
        user.annual_leave_balance -= leave.days
        logger.info(f"更新年假余额: {old_balance} -> {user.annual_leave_balance}")
    elif leave_type_str == "sick":
        old_balance = user.sick_leave_balance
        user.sick_leave_balance -= leave.days
        logger.info(f"更新病假余额: {old_balance} -> {user.sick_leave_balance}")
    
    # 确保更改被保存
    db.add(user)
    db.commit()
    
    # 刷新两个对象以获取最新数据
    db.refresh(db_leave)
    db.refresh(user)
    
    logger.info(f"提交后用户 {user_id} 假期余额: 年假={user.annual_leave_balance}, 病假={user.sick_leave_balance}")
    
    return db_leave

def get_leave_records(db: Session, user_id: str, skip: int = 0, limit: int = 100):
    return db.query(models.LeaveRecord).filter(
        models.LeaveRecord.user_id == user_id
    ).offset(skip).limit(limit).all()

def get_leave_record(db: Session, leave_id: int):
    return db.query(models.LeaveRecord).filter(models.LeaveRecord.leave_id == leave_id).first()

def delete_leave_record(db: Session, leave_id: int, user_id: str):
    db_leave = get_leave_record(db, leave_id)
    
    if not db_leave:
        raise HTTPException(status_code=404, detail="请假记录不存在")
    
    if db_leave.user_id != user_id:
        raise HTTPException(status_code=403, detail="无权删除此请假记录")
    
    # 恢复用户假期余额
    user = get_user(db, user_id)
    
    # 获取请假类型的字符串值
    leave_type_str = str(db_leave.leave_type.value if hasattr(db_leave.leave_type, 'value') else db_leave.leave_type)
    
    if leave_type_str == "annual":
        user.annual_leave_balance += db_leave.days
    elif leave_type_str == "sick":
        user.sick_leave_balance += db_leave.days
    
    # 确保用户更改被保存
    db.add(user)
    
    # 删除请假记录
    db.delete(db_leave)
    db.commit()
    
    # 刷新用户对象
    db.refresh(user)
    
    return {"message": "请假记录已删除"} 