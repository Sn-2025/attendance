from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import models
from .database import engine
from .routers import leave

# 创建数据库表
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="考勤系统 API",
    description="提供考勤系统的请假管理功能",
    version="1.0.0",
)

# 添加 CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 包含路由
app.include_router(leave.router)

@app.get("/")
def read_root():
    return {"message": "欢迎使用考勤系统 API"} 