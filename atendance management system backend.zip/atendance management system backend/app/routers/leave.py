from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List

from .. import crud, models, schemas
from ..database import get_db

router = APIRouter(
    prefix="/api/leave",
    tags=["leave"],
    responses={404: {"description": "Not found"}},
)

@router.get("/balance/{user_id}", response_model=schemas.LeaveBalanceResponse)
def get_leave_balance(user_id: str, db: Session = Depends(get_db)):
    """
    获取用户的剩余假期余额
    """
    user = crud.get_leave_balance(db, user_id)
    return {
        "user_id": user.id,
        "annual_leave_balance": user.annual_leave_balance,
        "sick_leave_balance": user.sick_leave_balance
    }

@router.post("/apply/{user_id}", response_model=schemas.LeaveResponse)
def apply_leave(user_id: str, leave: schemas.LeaveCreate, db: Session = Depends(get_db)):
    """
    申请请假
    """
    return crud.create_leave_record(db, leave, user_id)

@router.get("/records/{user_id}", response_model=List[schemas.LeaveResponse])
def get_leave_records(
    user_id: str, 
    skip: int = Query(0, description="跳过的记录数"), 
    limit: int = Query(100, description="返回的最大记录数"),
    db: Session = Depends(get_db)
):
    """
    获取用户的请假记录
    """
    records = crud.get_leave_records(db, user_id, skip=skip, limit=limit)
    return records

@router.delete("/records/{user_id}/{leave_id}")
def delete_leave_record(user_id: str, leave_id: int, db: Session = Depends(get_db)):
    """
    删除或撤销请假记录
    """
    return crud.delete_leave_record(db, leave_id, user_id) 