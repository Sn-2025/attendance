from sqlalchemy import Boolean, Column, Integer, String, Float, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship
import enum
import datetime

from .database import Base

class LeaveType(enum.Enum):
    annual = "annual"
    sick = "sick"

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, index=True)
    annual_leave_balance = Column(Float, default=20.0)  # 4周 = 20天
    sick_leave_balance = Column(Float, default=10.0)
    
    leave_records = relationship("LeaveRecord", back_populates="user")

class LeaveRecord(Base):
    __tablename__ = "leave_records"

    leave_id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"))
    leave_type = Column(Enum(LeaveType))  # 使用枚举类型而不是普通字符串
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    days = Column(Float)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="leave_records") 