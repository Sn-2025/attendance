from swarm import Agent,Swarm
from tools.general import get_remaining_leave_days,submit_leave_request
import json
from tools.general import get_current_time_with_weekday
from swarm.repl import run_demo_loop

User_Info = {'name':'张三','user_id':'123456'}

def instructions(context_variables):
    current_time_with_weekday = get_current_time_with_weekday()

    user_info = context_variables.get('user_info',User_Info)
    return f"""你是一个智能考勤管理助手，你的职责是帮助用户查询剩余假期、发起年假申请和病假申请。请严格按照下面的执行流程执行。

#上下文
当前时间: {current_time_with_weekday}。
用户信息:  {user_info}。

#执行流程
1.认真全面理解 message 信息输入
2.调用 tool 响应用户需求
2.1调用 get_remaining_leave_days 来获取用户剩余假期。
2.2调用 submit_leave_request 来发起请假流程。
3.返回用户处理结果

#注意
1.始终保持礼貌和耐心，友善地与用户互动。
2.确保所有答复符合用户输入语言，避免语言混用。
3.如需更多信息，请向用户发起询问。
4.遇到超出职责范围的请求，礼貌回复用户该问题超出你的职责范围。
5.当跟用户问候时，请带上用户的姓名。
6.年假和病假的时间不能重合。

"""



AttendanceManagementAgent = Agent(
    name="Attendance Management Agent",
    instructions=instructions,
    functions=[submit_leave_request, get_remaining_leave_days],
)




def get_answer(query):
    client = Swarm()
    response = client.run(
        agent=AttendanceManagementAgent,
        messages=[{"role": "user", "content": query}],
        debug=True,
        context_variables={'user_info':{'name':'张三','user_id':'123456'}},
        stream=False
    )

    return  response.messages[-1]["content"]




context_variables = {'user_info':{'name':'张三','user_id':'123456'}}
if __name__ == "__main__":
    run_demo_loop(AttendanceManagementAgent, context_variables=context_variables, debug=False)








