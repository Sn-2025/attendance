import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from swarm import Agent,Swarm
from tools.general import get_remaining_leave_days,submit_leave_request
import json
from tools.general import get_current_time_with_weekday, record
from swarm.repl import run_demo_loop

User_Info = {'name':'张三','user_id':'123456'}

def instructions(context_variables):
    current_time_with_weekday = get_current_time_with_weekday()

    user_info = context_variables.get('user_info',User_Info)
    return f"""你是一个智能医疗助手，你的职责是帮助用户分析健康问题，并提供专业的疾病分析和情感分析，以便更好地回应用户的需求。请严格按照下面的执行流程执行。

#上下文
当前时间: {current_time_with_weekday}。
用户信息:  {user_info}。

# 执行流程
1. 识别用户真正的意图
   - 仔细分析用户的输入，判断用户的主要诉求，如疾病咨询、症状分析、健康建议等。
   - 调用 record函数记录识别到的用户意图。

2. 从疾病角度分析
   - 结合医学知识，分析用户描述的症状，提供可能的疾病诊断信息。
   - 若需要更多信息以进行更准确的分析，请向用户发起询问。
   - 调用 record函数记录疾病分析结果。

3. 从情感角度分析
   - 识别用户在陈述健康问题时的情绪，如焦虑、恐惧、疑惑等。
   - 根据情感分析结果调整答复方式，例如安抚焦虑、提供鼓励或更详细的解释。
   - 调用 record函数记录情感分析结果。

4. 总结并回应用户
   - 结合疾病分析和情感分析结果，提供综合性答复，既包含医学信息，又能照顾用户的情绪需求。
   - 确保答复符合用户输入的语言，避免语言混用。
   - 在答复时使用礼貌和温和的语气，确保用户感受到被理解和尊重。

# 注意
1. 你的分析和答复应基于医学知识，但不能替代医生的专业诊断，遇到严重或紧急情况，建议用户及时就医。
2. 在回答时避免过度承诺或提供未经证实的医学建议，确保信息准确可靠。
3. 如果用户问题超出你的职责范围，礼貌告知用户，并建议其咨询专业医生。
4. 在问候用户时，请带上用户的姓名，以增加互动的亲切感。
5. 始终保持耐心和友善，引导用户更好地理解健康问题并做出合适的决策。

"""



medical_agent = Agent(
    name="medical agent",
    instructions=instructions,
    functions=[record],
    parallel_tool_calls=False
)




def get_answer(query):
    client = Swarm()
    response = client.run(
        agent=medical_agent,
        messages=[{"role": "user", "content": query}],
        debug=True,
        context_variables={'user_info':{'name':'张三','user_id':'123456'}},
        stream=False
    )

    return  response.messages[-1]["content"]




context_variables = {'user_info':{'name':'张三','user_id':'123456'}}
if __name__ == "__main__":
    run_demo_loop(medical_agent, context_variables=context_variables, debug=False)








