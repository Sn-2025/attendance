from datetime import datetime



def record(information):
    """
    用于记录思考和分析过程的函数
    参数：
        - information (str，必填): 需要记录的信息。
    """
    
    return f'信息已经成功记录。内容为：{information}'


def get_current_time_with_weekday():
    """
    获取当前时间、日期和星期几。
    """
    format = "%Y-%m-%d %H:%M:%S"
    now = datetime.now()
    formatted_time = now.strftime(format)
    weekday = now.strftime("%A")  # 获取星期几，全称（如 Monday）
    return f'The current time is {formatted_time}, {weekday}'


def get_remaining_leave_days(user_id):
    """
    获取用户的剩余假期天数。

    参数：
        - user_id (str，必填): 用户ID。

    返回值：
        - 剩余假期信息，包括年假、病假和其他假期天数。
    """
    return {
        "user_id": user_id,
        "annual_leave": 10,  # 模拟年假天数
        "sick_leave": 5,  # 模拟病假天数
    }


def submit_leave_request(user_id, leave_type, start_date, end_date):
    """
    提交请假申请。

    参数：
        - user_id (str，必填): 用户ID。
        - leave_type (str，必填): 请假类型（如年假、病假）。
        - start_date (str，必填): 请假开始日期（格式: YYYY-MM-DD）。
        - end_date (str，必填): 请假结束日期（格式: YYYY-MM-DD）。

    返回值：
        -  请假申请结果，包括申请状态和提示信息。
    """
    return {
        "user_id": user_id,
        "leave_type": leave_type,
        "start_date": start_date,
        "end_date": end_date,
        "status": "Pending",  # 模拟审批状态
        "message": "Your leave request has been submitted successfully."
    }


# # # # # 示例调用
# a = get_current_time_with_weekday()
# # #
# print(a)