import json
import os
def load_config():


    file_path = os.path.join(os.path.dirname(__file__), "config", "config.json")
    with open(file_path, "r") as file:
        config = json.load(file)
    return config