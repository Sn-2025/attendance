# Attendance Management Agent

基于AI代理的考勤管理系统，使用OpenAI API实现智能化的考勤管理和分析。

## 项目特性

- 基于Swarm架构的多代理系统
- 智能化考勤管理
- 灵活的工具集成
- 实时数据处理
- 可扩展的代理功能

## 目录结构

```
.
├── agents/         # AI代理定义
├── config/         # 配置文件
├── swarm/         # Swarm核心实现
├── tools/         # 工具函数集合
├── utils.py       # 通用工具函数
└── test.py        # 测试文件
```

## 环境要求

- Python 3.8+
- OpenAI API密钥

## 安装说明

1. 克隆项目到本地：
```bash
git clone [repository-url]
```

2. 安装依赖：
```bash
pip install -r requirements.txt
```

3. 配置OpenAI API密钥：
   - 在`config/config.json`中设置你的API密钥
   - 或者设置环境变量：`OPENAI_API_KEY=your-api-key`

## 使用方法

直接运行`test.py`文件即可启动考勤管理系统：

```bash
python test.py
```

系统会自动加载考勤管理代理，默认用户信息为：
- 用户名：张三
- 用户ID：123456

您可以通过修改`test.py`中的`context_variables`来更改用户信息。

## 许可证

MIT

## 贡献指南

欢迎提交Issue和Pull Request来帮助改进项目。

## 联系方式

如有问题或建议，请通过Issue与我们联系。 