from swarm.repl import run_demo_loop
from agents.AttendanceManagementAgent import *
context_variables = {'user_info':{'name':'张三','user_id':'123456'}}
if __name__ == "__main__":
    run_demo_loop(AttendanceManagementAgent, context_variables=context_variables, debug=False)


